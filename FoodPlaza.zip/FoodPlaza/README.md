# Food-Plaza
"Food Plaza" - A Java-based application for managing food orders, including admin and customer functionalities. Features include food inventory management, cart management, order processing, and database integration with MySQL for storing customer, food, and order data.
